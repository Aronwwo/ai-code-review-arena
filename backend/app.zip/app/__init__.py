"""AI Code Review Arena backend application."""
__version__ = "1.0.0"
